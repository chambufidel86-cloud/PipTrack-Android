# PipTrack Android app

PipTrack is an offline-first Android wrapper around the PipTrack Forex journal. It saves journal entries in the app's WebView storage and includes an Android-native JSON backup export to `Downloads/PipTrack`.

## Build an APK without installing Android Studio on your phone

This project includes a GitHub Actions workflow that builds a debug APK in the cloud.

1. Download and extract `PipTrack_Android_Project.zip`.
2. Create a new repository on GitHub and upload the extracted project files (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. Open **Build PipTrack APK** and tap **Run workflow**, or push the project to the `main` branch to trigger a build.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run and download the artifact named **PipTrack-debug-APK**.
7. Extract the artifact ZIP on your Android phone and tap `app-debug.apk`.
8. If Android asks, allow your browser or Files app to **Install unknown apps**, then return and install PipTrack.

## Notes

- The workflow builds a **debug APK** for personal installation. It is not a Play Store release.
- Requires Android 10 (API 29) or newer.
- Journal entries are stored on this device. Export backups regularly.
- PipTrack is a journal only; it does not connect to a broker or place trades.
